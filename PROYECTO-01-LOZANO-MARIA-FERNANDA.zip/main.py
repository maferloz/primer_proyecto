"""
This is the LifeStore-SalesList data:

lifestore-searches = [id_search, id product]
lifestore-sales = [idº_sale, id_product, score (from 1 to 5), date, refund (1 for true or 0 to false)]
lifestore-products = [id_product, name, price, category, stock]
"""

#aqui se esta importando la base de datos
from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches


#se va  acrear un for loop para determinar el total de ventas
contador = 0 
total_ventas = []   #[[id, contador], [id2, contador2]]

for producto in lifestore_products: #este es el for 1
  for venta in lifestore_sales: #este es el for 2
    if producto[0] == venta[1]:
      contador += 1
  
  formato_ideal = [producto[0], producto[1], contador]
  total_ventas.append(formato_ideal)
  contador = 0

#for total in total_ventas:   
  #print('El producto:', total[1], 'con el ID', total[0], 'se vendió', total[2], 'veces', '\n')

#se van a crear dos listas para sacar el total de ingresos y ventas
ventas = []
for i in total_ventas:
  v = i[2]
  ventas.append(v)
#total de ventas
#print('El total de ventas fue de:', sum(ventas))

precios = []
for i in lifestore_products:
  precio = i[2]
  precios.append(precio)

#total de ingresos
ingresos = []
for x, y in zip(precios, ventas):
  ingresos.append(x*y)

#print('El total de ingresos es de:', sum(ingresos), '\n')


#se filtró por mes para sacar un análisis mensual

listaventas =lifestore_sales
orden_lista = listaventas
lista_fechas = []

while orden_lista:
  fecha = orden_lista[0][3]
  lista_actual = orden_lista[0]
  for date in orden_lista:
    if date[3][3:10] < fecha:
      fecha = date[3][3:10]
      lista_actual = date
  lista_fechas.append(lista_actual)
  orden_lista.remove(lista_actual)


enero = lista_fechas[0:53]
febrero = lista_fechas[54:94]
marzo = lista_fechas[95:145]
abril = lista_fechas[145:220]
mayo = lista_fechas[221:256]
junio = lista_fechas[257:267]
julio = lista_fechas[268:278]
agosto = lista_fechas[279:282]

#total ingresos y ventas en enero
contador_en = 0 
total_ventas_en = []   #[[id, contador], [id2, contador2]]

for ide in lifestore_products: #este es el for 1
  for nombre in enero: #este es el for 2
    if ide[0] == nombre[1]:
      contador_en += 1
  
  formato_ideal_en = [ide[0], ide[1], contador_en]
  total_ventas_en.append(formato_ideal_en)
  contador_en = 0

ventas_en = []
for i in total_ventas_en:
  v = i[2]
  ventas_en.append(v)
#total de ventas
#print('El total de ventas en enero fue de:', sum(ventas_en))

precios_en = []
for i in lifestore_products:
  precio = i[2]
  precios_en.append(precio)

#total de ingresos
ingresos_en = []
for x, y in zip(precios_en, ventas_en):
  ingresos_en.append(x*y)

#print('El total de ingresos en enero fue de:', sum(ingresos_en), '\n')

#total ingresos y ventas en febrero
contador_feb = 0 
total_ventas_feb = []   #[[id, contador], [id2, contador2]]

for n in lifestore_products: #este es el for 1
  for c in febrero: #este es el for 2
    if n[0] == c[1]:
      contador_feb += 1
  
  formato_ideal_feb = [n[0], n[1], contador_feb]
  total_ventas_feb.append(formato_ideal_feb)
  contador_feb = 0

ventas_feb = []
for i in total_ventas_feb:
  v = i[2]
  ventas_feb.append(v)
#total de ventas
#print('El total de ventas en febrero fue de:', sum(ventas_feb))

precios_feb = []
for i in lifestore_products:
  precio = i[2]
  precios_feb.append(precio)

#total de ingresos
ingresos_feb = []
for x, y in zip(precios_feb, ventas_feb):
  ingresos_feb.append(x*y)

#print('El total de ingresos en febrero fue de:', sum(ingresos_feb), '\n')

#total ingresos y ventas en marzo
contador_mar = 0 
total_ventas_mar = []   #[[id, contador], [id2, contador2]]

for n in lifestore_products: #este es el for 1
  for c in marzo: #este es el for 2
    if n[0] == c[1]:
      contador_mar += 1
  
  formato_ideal_mar = [n[0], n[1], contador_mar]
  total_ventas_mar.append(formato_ideal_mar)
  contador_mar = 0

ventas_mar = []
for i in total_ventas_mar:
  v = i[2]
  ventas_mar.append(v)
#total de ventas
#print('El total de ventas en marzo fue de:', sum(ventas_mar))

precios_mar = []
for i in lifestore_products:
  precio = i[2]
  precios_mar.append(precio)

#total de ingresos
ingresos_mar = []
for x, y in zip(precios_mar, ventas_mar):
  ingresos_mar.append(x*y)

#print('El total de ingresos en marzo fue de:', sum(ingresos_mar), '\n')

#total ingresos y ventas en abril
contador_abr = 0 
total_ventas_abr = []   #[[id, contador], [id2, contador2]]

for n in lifestore_products: #este es el for 1
  for c in abril: #este es el for 2
    if n[0] == c[1]:
      contador_abr += 1
  
  formato_ideal_abr = [n[0], n[1], contador_abr]
  total_ventas_abr.append(formato_ideal_abr)
  contador_abr = 0

ventas_abr = []
for i in total_ventas_abr:
  v = i[2]
  ventas_abr.append(v)
#total de ventas
#print('El total de ventas en abril fue de:', sum(ventas_abr))

precios_abr = []
for i in lifestore_products:
  precio = i[2]
  precios_abr.append(precio)

#total de ingresos
ingresos_abr = []
for x, y in zip(precios_abr, ventas_abr):
  ingresos_abr.append(x*y)

#print('El total de ingresos en abril fue de:', sum(ingresos_abr), '\n')

#total ingresos y ventas en mayo
contador_may = 0 
total_ventas_may = []   #[[id, contador], [id2, contador2]]

for n in lifestore_products: #este es el for 1
  for c in mayo: #este es el for 2
    if n[0] == c[1]:
      contador_may += 1
  
  formato_ideal_may = [n[0], n[1], contador_may]
  total_ventas_may.append(formato_ideal_may)
  contador_may = 0

ventas_may = []
for i in total_ventas_may:
  v = i[2]
  ventas_may.append(v)
#total de ventas
#print('El total de ventas en mayo fue de:', sum(ventas_may))

precios_may = []
for i in lifestore_products:
  precio = i[2]
  precios_may.append(precio)

#total de ingresos
ingresos_may = []
for x, y in zip(precios_may, ventas_may):
  ingresos_may.append(x*y)

#print('El total de ingresos en mayo fue de:', sum(ingresos_may), '\n')

#total ingresos y ventas en junio
contador_jun = 0 
total_ventas_jun = []   #[[id, contador], [id2, contador2]]

for n in lifestore_products: #este es el for 1
  for c in junio: #este es el for 2
    if n[0] == c[1]:
      contador_jun += 1
  
  formato_ideal_jun = [n[0], n[1], contador_jun]
  total_ventas_jun.append(formato_ideal_jun)
  contador_jun = 0

ventas_jun = []
for i in total_ventas_jun:
  v = i[2]
  ventas_jun.append(v)
#total de ventas
#print('El total de ventas en junio fue de:', sum(ventas_jun))

precios_jun = []
for i in lifestore_products:
  precio = i[2]
  precios_jun.append(precio)

#total de ingresos
ingresos_jun = []
for x, y in zip(precios_jun, ventas_jun):
  ingresos_jun.append(x*y)

#print('El total de ingresos en junio fue de:', sum(ingresos_jun), '\n')

#total ingresos y ventas en julio
contador_jul = 0 
total_ventas_jul = []   #[[id, contador], [id2, contador2]]

for n in lifestore_products: #este es el for 1
  for c in julio: #este es el for 2
    if n[0] == c[1]:
      contador_jul += 1
  
  formato_ideal_jul = [n[0], n[1], contador_jul]
  total_ventas_jul.append(formato_ideal_jul)
  contador_jul = 0

ventas_jul = []
for i in total_ventas_jul:
  v = i[2]
  ventas_jul.append(v)
#total de ventas
#print('El total de ventas en julio fue de:', sum(ventas_jul))

precios_jul = []
for i in lifestore_products:
  precio = i[2]
  precios_jul.append(precio)

#total de ingresos
ingresos_jul = []
for x, y in zip(precios_jul, ventas_jul):
  ingresos_jul.append(x*y)

#print('El total de ingresos en julio fue de:', sum(ingresos_jul), '\n')

#total ingresos y ventas en agosto
contador_ago = 0 
total_ventas_ago = []   #[[id, contador], [id2, contador2]]

for n in lifestore_products: #este es el for 1
  for c in agosto: #este es el for 2
    if n[0] == c[1]:
      contador_ago += 1
  
  formato_ideal_ago = [n[0], n[1], contador_ago]
  total_ventas_ago.append(formato_ideal_ago)
  contador_ago = 0

ventas_ago = []
for i in total_ventas_ago:
  v = i[2]
  ventas_ago.append(v)
#total de ventas
#print('El total de ventas en agosto fue de:', sum(ventas_ago))

precios_ago = []
for i in lifestore_products:
  precio = i[2]
  precios_ago.append(precio)

#total de ingresos
ingresos_ago = []
for x, y in zip(precios_ago, ventas_ago):
  ingresos_ago.append(x*y)

#print('El total de ingresos en agosto fue de:', sum(ingresos_ago), '\n')

#ahora vemos cual es el mes con más ventas
ventas_meses = [sum(ventas_en), sum(ventas_feb), sum(ventas_mar), sum(ventas_abr), sum(ventas_may), sum(ventas_jun), sum(ventas_jul), sum(ventas_ago)]
#print('El mes con más ventas fue abril con', max(ventas_meses), 'ventas')

#se usará un while loop para ordenar los productos con más ventas
lista_ventas = total_ventas
mayores_ventas = []

while lista_ventas:
  mayor = lista_ventas[0][2]
  lista_nueva = lista_ventas[0]
  for venta in lista_ventas:
    if venta[2] > mayor:
      mayor = venta[2]
      lista_nueva = venta
  mayores_ventas.append(lista_nueva)
  lista_ventas.remove(lista_nueva)

#se usa slicing para sacar los productos con más ventas
topventas_50 = mayores_ventas[0:42]


#print('Los productos más vendidos son:', '\n')
#for x in topventas_50:
  #print('El producto', x[1], ', (ID:', x[0], ')' ', con', x[2], 'compras', '\n')

#se usa slicing para determinar los que obtuvieron menos ventas
ultventas_50 = mayores_ventas[-96:-46]

#print('Los productos con menos compras son: \n')
#for i in ultventas_50:
  #print('El producto', i[1], ', (ID:', i[0], ')', 'obtuvo', i[2], 'compras', '\n')


#se utiliza el mismo metodo para determinar los productos con mas busquedas
contador_busqueda = 0
total_busqueda = []

for producto in lifestore_products:
  for search in lifestore_searches:
    if producto[0] == search[1]:
      contador_busqueda += 1
    
  formato_busqueda = [producto[0], contador_busqueda]
  total_busqueda.append(formato_busqueda)
  contador_busqueda = 0

busquedas = total_busqueda
mayores_busquedas = []

while busquedas:
  mas = busquedas[0][1]
  otra_lista = busquedas[0]
  for busca in busquedas:
    if busca[1] > mas:
      mas = busca[1]
      otra_lista = busca
  mayores_busquedas.append(otra_lista)
  busquedas.remove(otra_lista)


#print('Los productos más buscados son: \n')
#for i in mayores_busquedas:
  #print('El producto con el ID', i[0], ', con', i[1], 'búsquedas \n')

ultbus_50 = mayores_busquedas[::-1]

#print('Los productos menos buscados son: \n')
#for i in ultbus_50:
  #print('El producto con el ID', i[0], ', con', i[1], 'búsquedas \n')


#productos mas populares y rezagados tomando en cuenta ventas y busquedas
top_productos = []
contador_top = 0


for x in mayores_ventas:
  for y in mayores_busquedas:
    if x[2] > 5 and y[1] > 5:
      contador_top += 1
  
  formato_top = [x[0], x[1]]
  top_productos.append(formato_top)
  contador_top = 0

#se usa slicing para determinar el top 10 de productos populares
top_10 = top_productos[0:10]
#print('Los productos más vendidos y buscados son: \n')
#for i in top_10:
  #print('El producto', i[1], 'con el ID', i[0], '\n')

#e igual para los 10 más rezagados
ult_10 = top_productos[-9:]
#print('Los productos con menos ventas y búsquedas son: \n')
#for i in ult_10:
  #print('El producto', i[1], 'con el ID', i[0], '\n')

#reseñas
lifestore_sales = [
    [1, 1, 5, '24/07/2020', 0],
    [2, 1, 5, '27/07/2020', 0],
    [3, 2, 5, '24/02/2020', 0],
    [4, 2, 5, '22/05/2020', 0],
    [5, 2, 5, '01/01/2020', 0],
    [6, 2, 5, '24/04/2020', 0],
    [7, 2, 4, '31/01/2020', 0],
    [8, 2, 4, '07/02/2020', 0],
    [9, 2, 4, '02/03/2020', 0],
    [10, 2, 4, '07/03/2020', 0],
    [11, 2, 4, '24/03/2020', 0],
    [12, 2, 4, '24/04/2020', 0],
    [13, 2, 4, '02/05/2020', 0],
    [14, 2, 4, '03/06/2020', 0],
    [15, 2, 3, '10/11/2019', 1],
    [16, 3, 5, '21/07/2020', 0],
    [17, 3, 4, '21/07/2020', 0],
    [18, 3, 5, '11/06/2020', 0],
    [19, 3, 5, '11/06/2020', 0],
    [20, 3, 5, '20/05/2020', 0],
    [21, 3, 5, '15/05/2020', 0],
    [22, 3, 5, '02/05/2020', 0],
    [23, 3, 5, '30/04/2020', 0],
    [24, 3, 5, '27/04/2020', 0],
    [25, 3, 4, '22/04/2020', 0],
    [26, 3, 5, '19/04/2020', 0],
    [27, 3, 5, '16/04/2020', 0],
    [28, 3, 3, '14/04/2020', 0],
    [29, 3, 5, '14/04/2020', 0],
    [30, 3, 5, '14/04/2020', 0],
    [31, 3, 5, '13/04/2020', 0],
    [32, 3, 5, '13/04/2020', 0],
    [33, 3, 5, '06/04/2020', 0],
    [34, 3, 5, '02/04/2020', 0],
    [35, 3, 5, '01/04/2020', 0],
    [36, 3, 5, '16/03/2020', 0],
    [37, 3, 5, '11/03/2020', 0],
    [38, 3, 4, '10/03/2020', 0],
    [39, 3, 5, '02/03/2020', 0],
    [40, 3, 5, '27/02/2020', 0],
    [41, 3, 4, '27/02/2020', 0],
    [42, 3, 5, '03/02/2020', 0],
    [43, 3, 5, '31/01/2020', 0],
    [44, 3, 5, '30/01/2020', 0],
    [45, 3, 5, '28/01/2020', 0],
    [46, 3, 5, '25/01/2020', 0],
    [47, 3, 5, '19/01/2020', 0],
    [48, 3, 5, '13/01/2020', 0],
    [49, 3, 5, '11/01/2020', 0],
    [50, 3, 4, '09/01/2020', 0],
    [51, 3, 5, '08/01/2020', 0],
    [52, 3, 4, '06/01/2020', 0],
    [53, 3, 5, '04/01/2020', 0],
    [54, 3, 5, '04/01/2020', 0],
    [55, 3, 5, '03/01/2020', 0],
    [56, 3, 5, '02/01/2020', 0],
    [57, 3, 5, '01/01/2020', 0],
    [58, 4, 4, '19/06/2020', 0],
    [59, 4, 4, '04/06/2020', 0],
    [60, 4, 5, '16/04/2020', 0],
    [61, 4, 4, '07/04/2020', 0],
    [62, 4, 5, '06/04/2020', 0],
    [63, 4, 5, '06/04/2020', 0],
    [64, 4, 5, '30/03/2020', 0],
    [65, 4, 4, '08/03/2020', 0],
    [66, 4, 5, '25/02/2020', 0],
    [67, 4, 3, '29/01/2020', 0],
    [68, 4, 5, '23/01/2020', 0],
    [69, 4, 4, '11/01/2020', 0],
    [70, 4, 5, '09/01/2020', 0],
    [71, 5, 4, '03/07/2020', 0],
    [72, 5, 4, '14/05/2020', 0],
    [73, 5, 4, '05/05/2020', 0],
    [74, 5, 5, '04/05/2020', 0],
    [75, 5, 4, '04/05/2020', 0],
    [76, 5, 5, '03/05/2020', 0],
    [77, 5, 5, '26/04/2020', 0],
    [78, 5, 5, '23/04/2020', 0],
    [79, 5, 5, '17/04/2020', 0],
    [80, 5, 5, '13/04/2020', 0],
    [81, 5, 5, '06/04/2020', 0],
    [82, 5, 5, '26/04/2020', 0],
    [83, 5, 5, '24/03/2020', 0],
    [84, 5, 5, '22/03/2020', 0],
    [85, 5, 4, '10/03/2020', 0],
    [86, 5, 5, '25/02/2020', 0],
    [87, 5, 4, '24/02/2020', 0],
    [88, 5, 5, '15/02/2020', 0],
    [89, 5, 5, '30/01/2020', 0],
    [90, 5, 5, '17/01/2020', 0],
    [91, 6, 5, '05/05/2020', 0],
    [92, 6, 5, '22/03/2020', 0],
    [93, 6, 5, '04/02/2020', 0],
    [94, 7, 5, '25/07/2020', 0],
    [95, 7, 5, '17/06/2020', 0],
    [96, 7, 5, '15/04/2020', 0],
    [97, 7, 5, '03/04/2020', 0],
    [98, 7, 5, '31/03/2020', 0],
    [99, 7, 5, '28/03/2020', 0],
    [100, 7, 5, '22/02/2020', 0],
    [101, 8, 5, '20/04/2020', 0],
    [102, 8, 5, '16/02/2020', 0],
    [103, 8, 5, '27/01/2020', 0],
    [104, 8, 5, '20/01/2020', 0],
    [105, 10, 4, '14/05/2020', 0],
    [106, 11, 5, '30/06/2020', 0],
    [107, 11, 5, '02/04/2020', 0],
    [108, 11, 5, '05/03/2020', 0],
    [109, 12, 5, '05/05/2020', 0],
    [110, 12, 4, '09/04/2020', 0],
    [111, 12, 5, '09/04/2020', 0],
    [112, 12, 5, '02/04/2020', 0],
    [113, 12, 5, '25/03/2020', 0],
    [114, 12, 5, '24/03/2020', 0],
    [115, 12, 5, '06/03/2020', 0],
    [116, 12, 5, '04/03/2020', 0],
    [117, 12, 4, '27/02/2020', 0],
    [118, 13, 4, '17/04/2020', 0],
    [119, 17, 1, '05/09/2020', 1],
    [120, 18, 5, '30/06/2020', 0],
    [121, 18, 4, '14/03/2020', 0],
    [122, 18, 5, '27/02/2020', 0],
    [123, 18, 4, '02/02/2020', 0],
    [124, 18, 4, '01/02/2020', 0],
    [125, 21, 5, '14/04/2020', 0],
    [126, 21, 5, '12/02/2020', 0],
    [127, 22, 5, '20/04/2020', 0],
    [128, 25, 5, '28/03/2020', 0],
    [129, 25, 5, '20/03/2020', 0],
    [130, 28, 5, '30/03/2020', 0],
    [131, 29, 4, '04/05/2020', 0],
    [132, 29, 5, '24/04/2020', 0],
    [133, 29, 4, '24/04/2020', 0],
    [134, 29, 4, '17/04/2020', 0],
    [135, 29, 5, '04/04/2020', 0],
    [136, 29, 5, '09/03/2020', 0],
    [137, 29, 5, '07/03/2020', 0],
    [138, 29, 5, '26/02/2020', 0],
    [139, 29, 5, '09/02/2020', 0],
    [140, 29, 5, '06/02/2020', 0],
    [141, 29, 5, '26/01/2020', 0],
    [142, 29, 4, '25/01/2020', 0],
    [143, 29, 1, '13/01/2020', 1],
    [144, 29, 1, '10/01/2020', 0],
    [145, 31, 1, '02/05/2020', 1],
    [146, 31, 1, '02/05/2020', 1],
    [147, 31, 1, '01/04/2020', 1],
    [148, 31, 4, '20/03/2020', 0],
    [149, 31, 3, '14/03/2020', 0],
    [150, 31, 1, '11/01/2020', 0],
    [151, 33, 5, '20/03/2020', 0],
    [152, 33, 4, '27/02/2020', 0],
    [153, 40, 5, '24/05/2020', 0],
    [154, 42, 5, '27/07/2020', 0],
    [155, 42, 5, '04/05/2020', 0],
    [156, 42, 4, '04/05/2020', 0],
    [157, 42, 4, '04/05/2020', 0],
    [158, 42, 5, '04/05/2020', 0],
    [159, 42, 5, '27/04/2020', 0],
    [160, 42, 5, '26/04/2020', 0],
    [161, 42, 4, '19/04/2020', 0],
    [162, 42, 5, '14/04/2020', 0],
    [163, 42, 5, '09/04/2020', 0],
    [164, 42, 4, '05/04/2020', 0],
    [165, 42, 4, '21/03/2020', 0],
    [166, 42, 5, '09/03/2020', 0],
    [167, 42, 5, '09/03/2020', 0],
    [168, 42, 5, '03/03/2020', 0],
    [169, 42, 4, '23/02/2020', 0],
    [170, 42, 4, '03/02/2020', 0],
    [171, 42, 4, '09/01/2020', 0],
    [172, 44, 5, '16/04/2020', 0],
    [173, 44, 5, '11/04/2020', 0],
    [174, 44, 5, '21/03/2020', 0],
    [175, 44, 4, '02/03/2020', 0],
    [176, 44, 4, '01/03/2020', 0],
    [177, 44, 5, '05/01/2020', 0],
    [178, 45, 1, '11/02/2020', 1],
    [179, 46, 2, '07/03/2020', 1],
    [180, 47, 4, '02/07/2020', 0],
    [181, 47, 5, '10/06/2020', 0],
    [182, 47, 5, '18/04/2020', 0],
    [183, 47, 4, '16/04/2020', 0],
    [184, 47, 5, '08/04/2020', 0],
    [185, 47, 4, '07/04/2020', 0],
    [186, 47, 5, '23/03/2020', 0],
    [187, 47, 5, '10/03/2020', 0],
    [188, 47, 3, '11/02/2020', 0],
    [189, 47, 5, '18/01/2020', 0],
    [190, 47, 5, '17/01/2020', 0],
    [191, 48, 4, '02/08/2020', 0],
    [192, 48, 3, '27/04/2020', 0],
    [193, 48, 5, '25/04/2020', 0],
    [194, 48, 5, '23/04/2020', 0],
    [195, 48, 5, '22/02/2020', 0],
    [196, 48, 5, '10/02/2020', 0],
    [197, 48, 5, '14/01/2020', 0],
    [198, 48, 5, '09/01/2020', 0],
    [199, 48, 5, '09/01/2020', 0],
    [200, 49, 5, '06/04/2020', 0],
    [201, 49, 5, '19/04/2020', 0],
    [202, 49, 5, '22/04/2020', 0],
    [203, 50, 5, '04/05/2020', 0],
    [204, 51, 5, '23/03/2020', 0],
    [205, 51, 4, '04/02/2020', 0],
    [206, 51, 5, '03/01/2020', 0],
    [207, 52, 5, '19/03/2020', 0],
    [208, 52, 5, '02/01/2020', 0],
    [209, 54, 4, '03/08/2020', 0],
    [210, 54, 5, '02/08/2020', 0],
    [211, 54, 5, '04/07/2020', 0],
    [212, 54, 5, '01/07/2020', 0],
    [213, 54, 5, '03/06/2020', 0],
    [214, 54, 5, '23/05/2020', 0],
    [215, 54, 4, '15/05/2020', 0],
    [216, 54, 5, '11/05/2020', 0],
    [217, 54, 5, '08/05/2020', 0],
    [218, 54, 5, '04/05/2020', 0],
    [219, 54, 4, '04/05/2002', 0],
    [220, 54, 5, '04/05/2020', 0],
    [221, 54, 5, '04/05/2020', 0],
    [222, 54, 4, '30/04/2020', 0],
    [223, 54, 4, '24/04/2020', 0],
    [224, 54, 5, '23/04/2020', 0],
    [225, 54, 4, '17/04/2020', 0],
    [226, 54, 5, '15/04/2020', 0],
    [227, 54, 5, '14/04/2020', 0],
    [228, 54, 4, '14/04/2020', 0],
    [229, 54, 5, '13/04/2020', 0],
    [230, 54, 5, '13/04/2020', 0],
    [231, 54, 5, '13/04/2020', 0],
    [232, 54, 5, '09/04/2020', 0],
    [233, 54, 5, '03/04/2020', 0],
    [234, 54, 5, '03/04/2020', 0],
    [235, 54, 5, '30/03/2020', 0],
    [236, 54, 5, '26/03/2020', 0],
    [237, 54, 5, '20/03/2020', 0],
    [238, 54, 2, '19/03/2020', 1],
    [239, 54, 5, '17/03/2020', 0],
    [240, 54, 5, '14/03/2020', 0],
    [241, 54, 5, '13/03/2020', 0],
    [242, 54, 4, '02/03/2020', 0],
    [243, 54, 5, '01/03/2020', 0],
    [244, 54, 5, '25/02/2020', 0],
    [245, 54, 5, '20/02/2020', 0],
    [246, 54, 4, '17/02/2020', 0],
    [247, 54, 5, '14/02/2020', 0],
    [248, 54, 5, '12/02/2020', 0],
    [249, 54, 4, '10/02/2020', 0],
    [250, 54, 5, '07/02/2020', 0],
    [251, 54, 5, '31/01/2020', 0],
    [252, 54, 5, '30/01/2020', 0],
    [253, 54, 5, '29/01/2020', 0],
    [254, 54, 5, '27/01/2020', 0],
    [255, 54, 5, '25/01/2020', 0],
    [256, 54, 5, '23/01/2020', 0],
    [257, 54, 5, '23/01/2020', 0],
    [258, 54, 4, '22/01/2020', 0],
    [259, 57, 5, '05/07/2020', 0],
    [260, 57, 5, '23/05/2020', 0],
    [261, 57, 5, '23/05/2020', 0],
    [262, 57, 5, '01/05/2020', 0],
    [263, 57, 5, '06/04/2020', 0],
    [264, 57, 5, '09/03/2020', 0],
    [265, 57, 5, '25/02/2020', 0],
    [266, 57, 5, '10/02/2020', 0],
    [267, 57, 4, '04/02/2020', 0],
    [268, 57, 5, '04/02/2020', 0],
    [269, 57, 5, '28/01/2020', 0],
    [270, 57, 5, '27/01/2020', 0],
    [271, 57, 4, '22/01/2020', 0],
    [272, 57, 5, '08/01/2020', 0],
    [273, 57, 5, '07/01/2020', 0],
    [274, 60, 5, '17/06/2020', 0],
    [275, 66, 5, '06/05/2020', 0],
    [276, 67, 5, '24/04/2020', 0],
    [277, 74, 4, '12/02/2020', 0],
    [278, 74, 5, '18/02/2020', 0],
    [279, 84, 5, '05/05/2020', 0],
    [280, 85, 5, '05/05/2020', 0],
    [281, 85, 5, '28/04/2020', 0],
    [282, 89, 3, '06/01/2020', 0],
    [283, 94, 4, '10/04/2020', 0]
]

resena = lifestore_sales
resena_ordenada = []

while resena:
  cinco = resena[0][2]
  resena_lista = resena[0]
  for calif in resena:
    if calif[2] > cinco:
      cinco = calif[2]
      resena_lista = calif
  resena_ordenada.append(resena_lista)
  resena.remove(resena_lista)

top_20 = resena_ordenada[0:20]
ult_20 = resena_ordenada[-20:]

#print('Las mejores reseñas:')
#for x in top_20:
  #print('El producto con el ID', x[1], 'fue calificado con', x[2], '\n')

#print('Las reseñas más bajas:')
#for x in ult_20:
  #print('El producto con el ID', x[1], 'fue calificado con',x[2], '\n' )


""""
INICIO DE SESIÓN
"""

#aqui se encuentran los usuarios aceptados y sus contraseñas
lista_admin = [['Admin1', 'abc123'], ['Admin2', 'xyz987'], ['Admin3', 'dfg456']]

user_inp = input('Favor de ingresar el usuario: ')
passw_inp = input('Ahora ingresa tu contraseña: ')

es_admin = 0

#en este loop se corren las distintas posibilidades de lo que ingresa el usuario y le muestra si se equivocó en usuario o en la contraseña o si ambos son incorrectas
for i in lista_admin:
  if i[0] == user_inp and i[1] == passw_inp:
    print('¡Hola bienvenido!')
    es_admin = 1
    break
  elif i[0] == user_inp and i[1] != passw_inp:
    print('Contraseña incorrecta, vuelva a intentarlo')
    break
  elif i[0] != user_inp and i[1] == passw_inp:
    print('Usuario incorrecto, vuelva a intentarlo ')
    break
  else:
    print('Usuario y contraseña incorrectos')
    break
  

if es_admin == 1:
  print('¡Bienvenido a Lifestore!')
else:
  print('No tienes acceso, intenta nuevamente')
    

"""
MENÚ
"""

if es_admin == 1:
  print('Bienvenido,', user_inp, ', elige una de las opciones: \n 1. Opción a: 50 productos con mayores ventas \n 2. Opción b: 100 productos con mayor búsquedas \n 3. Opción c: 50 productos con menores ventas \n 4. Opción d: 100 productos con menores búsquedas \n 5. Opción e: mejores y peores reseñas \n 6. Opción f: ingresos y ventas totales y mensuales')

if es_admin == 1:
  opcion_sel = input('Opción (letra): ')

correcta = 0

while correcta != 1:
  if opcion_sel == 'a':
    print('Seleccionaste a \n')
    print('Los productos más vendidos son:', '\n')
    for x in topventas_50:
      print('El producto', x[1], ', (ID:', x[0], ')' ', con', x[2], 'compras', '\n')
    correcta = 1
  elif opcion_sel == 'b':
    print('Seleccionaste b')
    print('Los productos más buscados son: \n')
    for i in mayores_busquedas:
      print('El producto con el ID', i[0], ', con', i[1], 'búsquedas \n')
    correcta = 1
  elif opcion_sel == 'c':
    print('Seleccionaste c')
    correcta = 1
    print('Los productos con menos compras son: \n')
    for i in ultventas_50:
      print('El producto', i[1], ', (ID:', i[0], ')', 'obtuvo', i[2], 'compras', '\n')
  elif opcion_sel == 'd':
    print('Seleccionaste d')
    print('Los productos menos buscados son: \n')
    for i in ultbus_50:
      print('El producto con el ID', i[0], ', con', i[1], 'búsquedas \n')
    correcta = 1
  elif opcion_sel == 'e':
    print('Seleccionaste e')
    print('Las mejores reseñas:')
    for x in top_20:
      print('El producto con el ID', x[1], 'fue calificado con', x[2], '\n')
    print('Las reseñas más bajas:')
    for x in ult_20:
      print('El producto con el ID', x[1], 'fue calificado con',x[2], '\n' )
    correcta = 1
  elif opcion_sel == 'f':
    print('Seleccionaste f')
    correcta = 1
    print('El total de ventas fue de:', sum(ventas))
    print('El total de ingresos es de:', sum(ingresos), '\n')
    print('El total de ventas en enero fue de:', sum(ventas_en))
    print('El total de ingresos en enero fue de:', sum(ingresos_en), '\n')
    print('El total de ventas en febrero fue de:', sum(ventas_feb))
    print('El total de ingresos en febrero fue de:', sum(ingresos_feb), '\n')
    print('El total de ventas en marzo fue de:', sum(ventas_mar))
    print('El total de ingresos en marzo fue de:', sum(ingresos_mar), '\n')
    print('El total de ventas en abril fue de:', sum(ventas_abr))
    print('El total de ingresos en abril fue de:', sum(ingresos_abr), '\n')
    print('El total de ventas en mayo fue de:', sum(ventas_may))
    print('El total de ingresos en mayo fue de:', sum(ingresos_may), '\n')
    print('El total de ventas en junio fue de:', sum(ventas_jun))
    print('El total de ingresos en junio fue de:', sum(ingresos_jun), '\n')
    print('El total de ventas en julio fue de:', sum(ventas_jul))
    print('El total de ingresos en julio fue de:', sum(ingresos_jul), '\n')
    print('El total de ventas en agosto fue de:', sum(ventas_ago))
    print('El total de ingresos en agosto fue de:', sum(ingresos_ago), '\n')
  else:
    print('Opción incorrecta')
    opcion_sel = input('Intente nuevamente: ')
  continue






  

